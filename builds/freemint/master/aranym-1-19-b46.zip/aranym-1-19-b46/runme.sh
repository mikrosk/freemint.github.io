aranym-mmu -c config

#
# Dial script
#
pppd call myppp
